-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 06, 2025 at 11:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `feedback`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `complaint` text NOT NULL,
  `student_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `complaint`, `student_id`, `faculty_id`, `status`) VALUES
(2, 'asd asd dasd asd', 2, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `branch` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `designation` varchar(45) DEFAULT NULL,
  `mobileno` varchar(45) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `name`, `branch`, `dob`, `designation`, `mobileno`, `gender`, `email`, `password`, `status`) VALUES
(2, 'Akshay asdasd', 'CO', '2025-03-27', 'asdasd', '9282928233', 'Female', 'akgbahadarpure1@gmail.com', '1234', 1),
(3, 'Shubham', 'CO', '2025-04-10', 'Teacher', '9383928292', 'Male', 'shubham@gmail.com', '1234', 0);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `session` varchar(255) DEFAULT NULL,
  `branch` varchar(255) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `semester` varchar(255) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `session`, `branch`, `year`, `semester`, `student_id`, `comment`) VALUES
(26, '2024-25', 'CO', 3, '6', 2, 'sad sadasd asdas');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_details`
--

CREATE TABLE `feedback_details` (
  `id` int(11) NOT NULL,
  `feedback_id` int(11) DEFAULT NULL,
  `question` text DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback_details`
--

INSERT INTO `feedback_details` (`id`, `feedback_id`, `question`, `faculty_id`, `subject_id`, `rating`) VALUES
(1, 26, 'Has the teacher covered entire syllabus as prescribed by university/ college/ board?', 3, 2, 1),
(2, 26, 'Has the teacher covered entire syllabus as prescribed by university/ college/ board?', 2, 1, 2),
(3, 26, 'Has the teacher covered relevant topic beyond syllabus?', 3, 2, 3),
(4, 26, 'Has the teacher covered relevant topic beyond syllabus?', 2, 1, 4),
(5, 26, 'Effectiveness of teacher in terms of technical content/ course content', 3, 2, 3),
(6, 26, 'Effectiveness of teacher in terms of technical content/ course content', 2, 1, 4),
(7, 26, 'Effectiveness of teacher in terms of communication skill', 3, 2, 3),
(8, 26, 'Effectiveness of teacher in terms of communication skill', 2, 1, 4),
(9, 26, 'Effectiveness of teacher in terms of use of teaching aids.', 3, 2, 3),
(10, 26, 'Effectiveness of teacher in terms of use of teaching aids.', 2, 1, 4),
(11, 26, 'Pace on which contents were covered\r\n', 3, 2, 2),
(12, 26, 'Pace on which contents were covered\r\n', 2, 1, 3),
(13, 26, 'Motivation and inspiration for students to learn', 3, 2, 2),
(14, 26, 'Motivation and inspiration for students to learn', 2, 1, 3),
(15, 26, 'Support for the development of students skill practical demonstration\r\n', 3, 2, 2),
(16, 26, 'Support for the development of students skill practical demonstration\r\n', 2, 1, 4),
(17, 26, 'Support for the development of students skill hands on training', 3, 2, NULL),
(18, 26, 'Support for the development of students skill hands on training', 2, 1, 2),
(19, 26, 'Clarity of expectation of students', 3, 2, 3),
(20, 26, 'Clarity of expectation of students', 2, 1, 3),
(21, 26, 'Feedback provided on students progress', 3, 2, 4),
(22, 26, 'Feedback provided on students progress', 2, 1, 4),
(23, 26, 'Willingness to offer help and advice to students', 3, 2, 5),
(24, 26, 'Willingness to offer help and advice to students', 2, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `description`) VALUES
(2, 'asda sdasd asd', 'as dasd asd'),
(3, 'asdasd', 'a sdasd asd asd');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `skill` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `name`, `skill`) VALUES
(1, 'Has the teacher covered entire syllabus as prescribed by university/ college/ board?', 'Syllabus Coverage'),
(2, 'Has the teacher covered relevant topic beyond syllabus?', 'Beyond Syllabus Knowledge'),
(3, 'Effectiveness of teacher in terms of technical content/ course content', 'Technical Expertise'),
(4, 'Effectiveness of teacher in terms of communication skill', 'Communication Skills'),
(5, 'Effectiveness of teacher in terms of use of teaching aids.', 'Use of Teaching Aids'),
(6, 'Pace on which contents were covered\r\n', 'Content Delivery Speed'),
(7, 'Motivation and inspiration for students to learn', 'Student Motivation'),
(8, 'Support for the development of students skill practical demonstration\r\n', 'Practical Demonstration Skills'),
(9, 'Support for the development of students skill hands on training', 'Hands-on Training Skills'),
(10, 'Clarity of expectation of students', 'Expectation Setting'),
(11, 'Feedback provided on students progress', 'Feedback Mechanism'),
(12, 'Willingness to offer help and advice to students', 'Student Support & Guidance');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `session` varchar(255) NOT NULL,
  `branch` varchar(45) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `semester` int(11) NOT NULL,
  `enrollmentno` varchar(45) DEFAULT NULL,
  `mobileno` varchar(45) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `session`, `branch`, `year`, `semester`, `enrollmentno`, `mobileno`, `gender`, `email`, `password`, `status`) VALUES
(2, 'Akshay sadasd', '2024-25', 'CO', 3, 6, '23423423', '9282928233', 'Male', 'akgbahadarpure1@gmail.com', '12345', 2),
(3, 'NIkhil', '', 'CO', 1, 0, '45678', '2342342342', 'Male', 'nikhil@gmail.com', '12345', 0);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `session` varchar(255) NOT NULL,
  `year` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `branch` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `session`, `year`, `semester`, `subject`, `faculty_id`, `branch`) VALUES
(1, '2024-25', 3, 6, 'ABC', 2, 'CO'),
(2, '2024-25', 3, 6, 'PQR', 3, 'CO'),
(5, '2025-26', 3, 4, 'ABC', 2, 'CO'),
(8, '2024-25', 3, 4, 'ABC', 2, 'CO'),
(9, '2024-25', 1, 1, 'ABC', 2, 'CO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback_details`
--
ALTER TABLE `feedback_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `feedback_details`
--
ALTER TABLE `feedback_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
