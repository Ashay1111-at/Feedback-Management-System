<?php
include("includes/dbconfig.php"); 
$studid = $_SESSION['user_id']; 

$query = "SELECT * FROM student where id='$studid'";
$statement = $conn->prepare($query);
$statement->execute();
$statement->setFetchMode(PDO::FETCH_OBJ);
$resultstudent = $statement->fetch();

if(isset($_POST['session'])) {
    $session = $_POST['session'];
    $semester = $_POST['semester'];
    $branch = $_POST['branch'];
    $year = $_POST['year'];
    $comment = $_POST['comment'];

    $query = "SELECT * FROM feedback where session='$session' and semester='$semester' and branch='$branch' and year='$year' and student_id='$studid'";
        $statement = $conn->prepare($query);
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_OBJ);
        $resultexist = $statement->fetch();
        
        if($resultexist){
            $_SESSION['status'] = 2;
        }else {
            
            $query = "INSERT INTO feedback (session,semester,branch,year,student_id,comment) VALUES (:session,:semester,:branch,:year,:student_id,:comment)";
            $query_run = $conn->prepare($query);
            $data = [
                ':session' => $session,
                ':semester' => $semester,
                ':branch' => $branch,
                ':year' => $year,
                ':student_id' => $studid,
                ':comment' => $comment
            ];
            $query_execute = $query_run->execute($data);
            $lastid = $conn->lastInsertId();
            if($lastid > 0){
                $question = $_POST["question"];
                $questionid = $_POST["questionid"];
                // print_r($questionid);
                for($i=0;$i<count($questionid);$i++)
                {
                    $facultyids = $_POST["faculty".$questionid[$i]];
                    $subjectids = $_POST["subject".$questionid[$i]];
                    foreach($facultyids as $key => $facultyid){
                        $qname = $question[$i];
                        $subjectid = $subjectids[$key];
                        $option = null;
                        if(isset($_POST["options".$facultyid."".$questionid[$i]."".$subjectid])){
                            $option = $_POST["options".$facultyid."".$questionid[$i]."".$subjectid];
                        }
                        
                        // echo $questionid[$i], $qname, $facultyid;
                        // print_r($option);
                        $query1 = "INSERT INTO feedback_details (feedback_id,question,faculty_id,subject_id,rating) VALUES (:feedback_id,:question,:faculty_id,:subject_id,:rating)";
                        $query_run1 = $conn->prepare($query1);
                        $data1 = [
                            ':feedback_id' => $lastid,
                            ':question' => $qname,
                            ':faculty_id' => $facultyid,
                            ':subject_id' => $subjectid,
                            ':rating' => $option
                        ];
                        $query_run1->execute($data1);
                        
                    }
                }
            }

            if($query_execute) {
                $_SESSION['status'] = 1;
            }
            else {
                $_SESSION['status'] = 0;
            }
        }
}
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="TemplateMo">

        <title>Feedback Management System</title>

        <!-- CSS FILES -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">

        <link href="css/bootstrap.min.css" rel="stylesheet">

        <link href="css/bootstrap-icons.css" rel="stylesheet">

        <link href="css/magnific-popup.css" rel="stylesheet">

        <link href="css/templatemo-first-portfolio-style.css" rel="stylesheet">
        <style>
            table th,table td{
                text-align: center;
            }
        </style>
    </head>
    
    <body>

        <section class="preloader">
            <div class="spinner">
                <span class="spinner-rotate"></span>    
            </div>
        </section>

        <?php include("includes/student-header.php"); ?>

        <main>
            <section class="hero d-flex justify-content-center align-items-center" style="padding-top: 0px; padding-bottom: 70px;" id="section_1">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-9 col-12">
                            <div class="hero-text">
                                <h2 class="mb-4">Feedback management system</h2>
                            </div>
                        </div>
                    </div>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#535da1" fill-opacity="1" d="M0,160L24,160C48,160,96,160,144,138.7C192,117,240,75,288,64C336,53,384,75,432,106.7C480,139,528,181,576,208C624,235,672,245,720,240C768,235,816,213,864,186.7C912,160,960,128,1008,133.3C1056,139,1104,181,1152,202.7C1200,224,1248,224,1296,197.3C1344,171,1392,117,1416,90.7L1440,64L1440,0L1416,0C1392,0,1344,0,1296,0C1248,0,1200,0,1152,0C1104,0,1056,0,1008,0C960,0,912,0,864,0C816,0,768,0,720,0C672,0,624,0,576,0C528,0,480,0,432,0C384,0,336,0,288,0C240,0,192,0,144,0C96,0,48,0,24,0L0,0Z"></path></svg>
            </section>

            <section class="contact section-padding" id="section_5">
                    <div class="container">
                        <div class="row">
                        <div class="col-md-12">
                        <?php
                          
                        ?>
                    </div>
                            <div class="col-lg-8 col-md-8 col-12">
                            <?php
                            if(isset($_SESSION['status']))
                            {
                                    if($_SESSION['status'] == 1){
                                        ?>
                                        <label class="alert alert-success" style="width:100%">Feedback submitted successfully!</label>
                                        <?php
                                    }else if($_SESSION['status'] == 2){
                                        ?>
                                        <label class="alert alert-warning" style="width:100%">Feedback already submitted!</label>
                                        <?php
                                    }else{
                                        
                                    }
                                    $_SESSION['status']="";
                                }
                            ?>
                                <div class="section-title-wrap d-flex justify-content-center align-items-center mb-5">
                                    <img src="images/aerial-view-man-using-computer-laptop-wooden-table.jpg" class="avatar-image img-fluid" alt="">

                                    <h2 class="text-white ms-4 mb-0">Submit New Feedback</h2>
                                </div>
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-lg-12 col-12 mt-5 mt-lg-0">
                                <form action="" method="post" class="custom-form contact-form" onsubmit="return confirm('Are you sure?')" role="form">
                                    <div class="row">
                                        <div class="col-lg-3 col-md-3 col-12"> 
                                            <div class="form-floating">
                                                <select class="form-control" name="session" required>
                                                    <option value="<?=$resultstudent->session?>"><?=$resultstudent->session?></option>
                                                </select>
                                                <label for="floatingInput">Session</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-3 col-12"> 
                                            <div class="form-floating">
                                                <select class="form-control" name="branch" required>
                                                    <option value="<?=$resultstudent->branch?>"><?=$resultstudent->branch?></option>
                                                </select>
                                                <label for="floatingInput">Branch</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-3 col-12"> 
                                            <div class="form-floating">
                                                <select class="form-control" name="year" required>
                                                    <option value="<?=$resultstudent->year?>"><?=$resultstudent->year?></option>
                                                </select>
                                                <label for="floatingInput">Year</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-3 col-12"> 
                                            <div class="form-floating">
                                                <select class="form-control" name="semester" required>
                                                    <option value="<?=$resultstudent->semester?>"><?=$resultstudent->semester?></option>
                                                </select>
                                                <label for="floatingInput">Semester</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-12">
                                            <table class="table">
                                        <?php
                                            $query = "SELECT * FROM questions order by id asc";
                                            $statement = $conn->prepare($query);
                                            $statement->execute();
                                            $questions = $statement->fetchAll(PDO::FETCH_OBJ);
                                            $i = 1;
                                            if($questions){
                                                foreach($questions as $question){
                                                    $qid = $question->id;
                                                    ?>
                                                    <tr>
                                                        <td>
                                                            <input type="hidden" name="question[]" value="<?=$question->name?>" />
                                                            <input type="hidden" name="questionid[]" value="<?=$question->id?>" />
                                                        <table class="table">
                                                            <tr>
                                                             <td style="text-align: left;" colspan="6"> <b> <?=$i++?>.) </b><?=$question->name?></td>   
                                                            </tr>
                                                            <tr>
                                                                <th style="width:30%; text-align: left;"></th>
                                                                <th align="center">Very Poor</th>
                                                                <th align="center">Poor</th>
                                                                <th align="center">Good</th>
                                                                <th align="center">Very Good</th>
                                                                <th align="center">Excellent</th>
                                                            </tr>
                                                            <tr>
                                                            <?php
                                                                $session = $resultstudent->session;
                                                                $branch = $resultstudent->branch;
                                                                $year = $resultstudent->year;
                                                                $semester = $resultstudent->semester;

                                                                $query = "SELECT * FROM subjects where branch = '$branch' and session = '$session' and year = '$year' and semester = '$semester' order by id desc";
                                                                $statement = $conn->prepare($query);
                                                                $statement->execute();
                                                                $results = $statement->fetchAll(PDO::FETCH_OBJ);
                                                                if($results){
                                                                    foreach($results as $result){
                                                                        $facultyid=$result->faculty_id;
                                                                        $sub_id=$result->id;

                                                                        $query1 = "SELECT * FROM faculty where id='$facultyid'";
                                                                        $statement1 = $conn->prepare($query1);
                                                                        $statement1->execute();
                                                                        $statement1->setFetchMode(PDO::FETCH_OBJ);
                                                                        $resultfaculty = $statement1->fetch();
                                                                        if($resultfaculty){
                                                                        ?>
                                                                        <input type="hidden" name="faculty<?=$qid?>[]" value="<?=$result->faculty_id?>" />
                                                                        <input type="hidden" name="subject<?=$qid?>[]" value="<?=$result->id?>" />
                                                                                <tr>
                                                                                    <td style="width:30%; text-align: left;" ><?=$resultfaculty->name?> (<?=$result->subject?>)</td>
                                                                                    <td align="center">
                                                                                        <input type="radio" name="options<?=$facultyid?><?=$qid?><?=$sub_id?>" value="1"/>
                                                                                    </td>
                                                                                    <td align="center">
                                                                                        <input type="radio" name="options<?=$facultyid?><?=$qid?><?=$sub_id?>" value="2"/>
                                                                                    </td>
                                                                                    <td align="center">
                                                                                        <input type="radio" name="options<?=$facultyid?><?=$qid?><?=$sub_id?>" value="3"/>
                                                                                    </td>
                                                                                    <td align="center">
                                                                                        <input type="radio" name="options<?=$facultyid?><?=$qid?><?=$sub_id?>" value="4"/>
                                                                                    </td>
                                                                                    <td align="center">
                                                                                        <input type="radio" name="options<?=$facultyid?><?=$qid?><?=$sub_id?>" value="5"/>
                                                                                    </td>
                                                                                </tr>
                                                                        <?php
                                                                        }
                                                                    }
                                                                }
                                                                ?>
                                                            </tr>
                                                        </table>
                                                        </td>
                                                   </tr>
                                                    <?php
                                                }
                                            }
                                        ?>
                                        </table>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-12"> 
                                            <div class="form-floating">
                                                <textarea name="comment" class="form-control" required></textarea>
                                                <label for="floatingInput">Write here your feedback about college.</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-3 col-12 ms-auto">
                                            <button type="submit" class="form-control">Submit</button>
                                        </div>

                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </section>

        </main>

        <?php include("includes/footer.php"); ?>

        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/click-scroll.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/magnific-popup-options.js"></script>
        <script src="js/custom.js"></script>

    </body>
</html>