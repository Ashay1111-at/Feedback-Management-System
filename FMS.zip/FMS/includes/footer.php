<footer class="site-footer">
   <div class="container">
         <div class="row">

            <div class="col-lg-12 col-12">
               <div class="copyright-text-wrap">
                     <p class="mb-0">
                        <span class="copyright-text">Copyright © 2025. All rights reserved.</span>
                     </p>
               </div>
            </div>

         </div>
   </div>
</footer>