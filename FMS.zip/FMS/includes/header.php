<?php 
$current_page = basename($_SERVER['SCRIPT_NAME']); // Get the current page name
?>
<nav class="navbar navbar-expand-lg">
            <div class="container">

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <a href="index.html" class="navbar-brand mx-auto mx-lg-0">FMS</a>

                <div class="d-flex align-items-center d-lg-none">
                    <i class="navbar-icon bi-telephone-plus me-3"></i>
                    <a class="custom-btn btn" href="#section_5">
                        120-240-9600
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-lg-5">
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'index.php') ? 'active' : ''; ?>" href="index.php">Home</a>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link <?= ($current_page == 'about.php') ? 'active' : ''; ?>" href="about.php">About</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'faq.php') ? 'active' : ''; ?>" href="faq.php">FAQ's</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'login.php') ? 'active' : ''; ?>" href="login.php">Student Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'faculty-login.php') ? 'active' : ''; ?>" href="faculty-login.php">Faculty Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'admin-login.php') ? 'active' : ''; ?>" href="admin-login.php">Admin Login</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'contact.php') ? 'active' : ''; ?>" href="contact.php">Contact</a>
                        </li>
                    </ul>

                    <div class="d-lg-flex align-items-center d-none ms-auto">
                        <i class="navbar-icon bi-telephone-plus me-3"></i>
                        <a class="custom-btn btn" href="#section_5">
                            120-240-9600
                        </a>
                    </div>
                </div>

            </div>
        </nav>