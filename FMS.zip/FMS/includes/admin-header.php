<?php 
$current_page = basename($_SERVER['SCRIPT_NAME']); // Get the current page name
?>
<nav class="navbar navbar-expand-lg">
            <div class="container">

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <a href="index.html" class="navbar-brand mx-auto mx-lg-0">FMS</a>

                <div class="d-flex align-items-center d-lg-none">
                    <i class="navbar-icon bi-telephone-plus me-3"></i>
                    <a class="custom-btn btn" href="#section_5">
                        120-240-9600
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-lg-5">
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'admin-faculty.php') ? 'active' : ''; ?>" href="admin-faculty.php">Faculty</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'admin-students.php') ? 'active' : ''; ?>" href="admin-students.php">Students</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'admin-complaints.php') ? 'active' : ''; ?>" href="admin-complaints.php">Complaints</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'admin-feedback.php') ? 'active' : ''; ?>" href="admin-feedback.php">Feedbacks</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'admin-contacts.php') ? 'active' : ''; ?>" href="admin-contacts.php">Contacts</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'admin-profile.php') ? 'active' : ''; ?>" href="admin-profile.php">Profile</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    </ul>

                    <div class="d-lg-flex align-items-center d-none ms-auto">
                        <i class="navbar-icon bi-telephone-plus me-3"></i>
                        <a class="custom-btn btn" href="#section_5">
                            120-240-9600
                        </a>
                    </div>
                </div>

            </div>
        </nav>