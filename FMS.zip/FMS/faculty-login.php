<?php
include("includes/dbconfig.php"); 

if(isset($_POST['facultyform']))
{
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM faculty where email='$email' and password='$password'";
    $statement = $conn->prepare($query);
    $statement->execute();
    $result = $statement->fetch(PDO::FETCH_OBJ);
    // print_r($result);
    if($result){
        $_SESSION['user'] = "faculty";
        $_SESSION['user_id'] = $result->id;
        $_SESSION['status'] = 11;
        header("Location: faculty-profile.php");
        exit;
    }else
    {
        $_SESSION['status'] = 10;
    }
}

    if(isset($_POST['name'])) {
        $name = $_POST['name'];
        $branch = $_POST['branch'];
        $dob = $_POST['dob'];
        $designation = $_POST['designation'];
        $mobileno = $_POST['mobileno'];
        $gender = $_POST['gender'];
        $email = $_POST['email'];
        $password = $_POST['password'];

            $query = "SELECT * FROM faculty where email='$email'";
            $statement = $conn->prepare($query);
            $statement->execute();
            $statement->setFetchMode(PDO::FETCH_OBJ);
            $resultexist = $statement->fetchAll();
            
            if($resultexist){
                $_SESSION['status'] = 2;
            }else {
                $query = "INSERT INTO faculty (name, branch, dob, designation, gender, mobileno, email, password) VALUES (:name, :branch, :dob, :designation, :gender, :mobileno, :email, :password)";
                $query_run = $conn->prepare($query);
                $data = [
                    ':name' => $name,
                    ':branch' => $branch,
                    ':dob' => $dob,
                    ':designation' => $designation,
                    ':gender' => $gender,
                    ':mobileno' => $mobileno,
                    ':email' => $email,
                    ':password' => $password
                ];
                $query_execute = $query_run->execute($data);

                if($query_execute) {
                    $_SESSION['status'] = 1;
                }
                else {
                    $_SESSION['status'] = 0;
                }
            }
    }

?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="TemplateMo">

        <title>Feedback Management System</title>

        <!-- CSS FILES -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">

        <link href="css/bootstrap.min.css" rel="stylesheet">

        <link href="css/bootstrap-icons.css" rel="stylesheet">

        <link href="css/magnific-popup.css" rel="stylesheet">

        <link href="css/templatemo-first-portfolio-style.css" rel="stylesheet">
    </head>
    
    <body>

        <section class="preloader">
            <div class="spinner">
                <span class="spinner-rotate"></span>    
            </div>
        </section>

        <?php include("includes/header.php"); ?>

        <main>
            <section class="hero d-flex justify-content-center align-items-center" style="padding-top: 0px; padding-bottom: 70px;" id="section_1">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-9 col-12">
                            <div class="hero-text">
                                <h2 class="mb-4">Feedback management system</h2>
                            </div>
                        </div>
                    </div>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#535da1" fill-opacity="1" d="M0,160L24,160C48,160,96,160,144,138.7C192,117,240,75,288,64C336,53,384,75,432,106.7C480,139,528,181,576,208C624,235,672,245,720,240C768,235,816,213,864,186.7C912,160,960,128,1008,133.3C1056,139,1104,181,1152,202.7C1200,224,1248,224,1296,197.3C1344,171,1392,117,1416,90.7L1440,64L1440,0L1416,0C1392,0,1344,0,1296,0C1248,0,1200,0,1152,0C1104,0,1056,0,1008,0C960,0,912,0,864,0C816,0,768,0,720,0C672,0,624,0,576,0C528,0,480,0,432,0C384,0,336,0,288,0C240,0,192,0,144,0C96,0,48,0,24,0L0,0Z"></path></svg>
            </section>

            <section class="contact section-padding" id="section_5">
                    <div class="container">
                        <div class="row">
                        <div class="col-md-12">
                        <?php
                            if(isset($_SESSION['status']))
                            {
                                if($_SESSION['status'] == 1){
                                    ?>
                                    <label class="alert alert-success" style="width:100%">New faculty created successfully!</label>
                                    <?php
                                }else if($_SESSION['status'] == 2){
                                    ?>
                                    <label class="alert alert-warning" style="width:100%">Faculty email id already exist!</label>
                                    <?php
                                } else if ($_SESSION['status'] == 4) {
                                    ?>
                                    <label class="alert alert-danger" style="width:100%">OTP incorrect</label>
                                    <?php
                                } else if($_SESSION['status'] == 0){
                                    ?>
                                    <label class="alert alert-danger" style="width:100%">Form not submitted</label>
                                    <?php
                                }else if($_SESSION['status'] == 11){
                                    ?>
                                    <label class="alert alert-success" style="width:100%">Login <?php if(isset($_SESSION['user'])){ echo $_SESSION['user']; } ?> successfully!</label>
                                    <?php
                                }else if($_SESSION['status'] == 10){
                                    ?>
                                    <label class="alert alert-danger" style="width:100%">Email Id / Password invalid!</label>
                                    <?php
                                }else if($_SESSION['status'] == 5){
                                    ?>
                                    <label class="alert alert-success" style="width:100%">Password reset successfully!</label>
                                    <?php
                                }else{
                                    
                                }
                                
                                $_SESSION['status'] = "";
                            }
                        ?>
                    </div>
                            <div class="col-lg-8 col-md-8 col-12">
                                <div class="section-title-wrap d-flex justify-content-center align-items-center mb-5">
                                    <img src="images/aerial-view-man-using-computer-laptop-wooden-table.jpg" class="avatar-image img-fluid" alt="">

                                    <h2 class="text-white ms-4 mb-0">Faculty Login / Register</h2>
                                </div>
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-lg-6 col-md-6 col-12 pe-lg-0">
                                <h2 class="ms-2 mb-0">Login</h2>
                                <form action="" method="post" class="custom-form contact-form" role="form">
                                <input type="hidden" name="facultyform" value="123"/>
                                    <div class="row">
                                        <div class="col-lg-12 col-md-6 col-12"> 
                                            <div class="form-floating">
                                                <input type="email" name="email" id="email" pattern="[^ @]*@[^ @]*" class="form-control" placeholder="Email address" required="">
                                                
                                                <label for="floatingInput">Email address</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-6 col-12">
                                            <div class="form-floating">
                                                <input type="password" name="password" id="name" class="form-control" placeholder="Password" required="">
                                                
                                                <label for="floatingInput">Password</label>
                                            </div>
                                            <a href="faculty-forgot.php">Forgot Password?</a>
                                        </div>
                                        <div class="col-lg-3 col-12 ms-auto">
                                            <button type="submit" class="form-control">Login</button>
                                        </div>

                                    </div>
                                </form>
                            </div>

                            <div class="col-lg-6 col-12 mt-5 mt-lg-0">
                                <h2 class="ms-2 mb-0">Register</h2>
                                <form action="" method="post" class="custom-form contact-form" role="form">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-12">
                                            <div class="form-floating">
                                                <input type="text" name="name" id="name" class="form-control" placeholder="Name" required>
                                                <label for="floatingInput">Name</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12"> 
                                            <div class="form-floating">
                                                <select name="branch" id="branch" class="form-control" required>
                                                <option>CO</option>
                                                <option>IT</option>
                                                </select>
                                                <label for="floatingInput">Branch</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12"> 
                                            <div class="form-floating">
                                                <input type="date" name="dob" id="dob" class="form-control" placeholder="Date of birth" required>
                                                
                                                <label for="floatingInput">Date of Birth</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12"> 
                                            <div class="form-floating">
                                                <input type="text" name="designation" id="designation" class="form-control" required>
                                                
                                                <label for="floatingInput">Designation</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-6 col-md-6 col-12"> 
                                            <div class="form-floating">
                                                <input type="number" name="mobileno" id="mobileno" class="form-control" required>
                                                
                                                <label for="floatingInput">Mobile No</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12"> 
                                            <div class="form-floating">
                                                <select name="gender" id="male" value="Male" class="form-control">
                                                <option>Male</option>
                                                <option>Female</option>
                                                </select>
                                                <label for="floatingInput">Gender</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12"> 
                                            <div class="form-floating">
                                                <input type="email" name="email" id="email" pattern="[^ @]*@[^ @]*" class="form-control" placeholder="Email address" required>
                                                
                                                <label for="floatingInput">Email address</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12"> 
                                            <div class="form-floating">
                                                <input type="password" name="password" id="password" class="form-control" required>
                                                
                                                <label for="floatingInput">Password</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-12 ms-auto">
                                            <button type="submit" name="faculty-register" class="form-control">Register</button>
                                        </div>

                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </section>

        </main>

        <?php include("includes/footer.php"); ?>

        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/click-scroll.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/magnific-popup-options.js"></script>
        <script src="js/custom.js"></script>

    </body>
</html>