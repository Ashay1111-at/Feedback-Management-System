<?php
include("includes/dbconfig.php"); 

if(isset($_POST["email"])){
    $otp = rand ( 100000 , 999999 );
    
    $email = $_POST["email"];

    $_SESSION['otp'] = $otp;
    
    $url="https://threeartisans.com/sendmail.php?type=feedback&email=".$email."&full_name=".$email."&otp=".$otp."&subject=New+OTP+for+verification";
    echo file_get_contents($url);

    echo $otp;
}